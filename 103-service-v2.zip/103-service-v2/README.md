# 103 SERVICE — Android

A clean Android media URL app inspired by the supplied reference screens.

### UI
- Black + royal gold visual identity
- Splash screen with 103 SERVICE branding
- Home screen inspired by the reference layout
- Side navigation drawer
- Add URL screen
- URL library with play/delete
- Full-screen landscape player

### Build with GitHub
The included GitHub Actions workflow builds a debug APK on every push to `main` or manually via **Actions → Build 103 SERVICE APK → Run workflow**.

### Important
Use only media URLs and content you own or are authorized to access.
