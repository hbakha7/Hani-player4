package com.service103.app

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.service103.app.databinding.ActivityAddUrlBinding

class AddUrlActivity : AppCompatActivity() {
    private lateinit var binding: ActivityAddUrlBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddUrlBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.backButton.setOnClickListener { finish() }
        binding.saveButton.setOnClickListener {
            val title = binding.titleInput.text.toString().trim()
            val url = binding.urlInput.text.toString().trim()
            val agent = binding.agentInput.text.toString().trim()

            if (title.isEmpty() || url.isEmpty()) {
                Toast.makeText(this, "Please enter a title and URL.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            UrlStore.add(this, UrlItem(title, url, agent))
            Toast.makeText(this, "Saved successfully.", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
}
