package com.service103.app

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.service103.app.databinding.ItemUrlBinding

class UrlAdapter(
    private val onPlay: (UrlItem) -> Unit,
    private val onDelete: (Int) -> Unit
) : RecyclerView.Adapter<UrlAdapter.Holder>() {

    private val items = mutableListOf<UrlItem>()

    fun submit(newItems: List<UrlItem>) {
        items.clear()
        items.addAll(newItems)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
        return Holder(ItemUrlBinding.inflate(LayoutInflater.from(parent.context), parent, false))
    }

    override fun onBindViewHolder(holder: Holder, position: Int) = holder.bind(items[position], position)
    override fun getItemCount() = items.size

    inner class Holder(private val b: ItemUrlBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(item: UrlItem, position: Int) {
            b.title.text = item.title
            b.url.text = item.url
            b.play.setOnClickListener { onPlay(item) }
            b.delete.setOnClickListener { onDelete(position) }
        }
    }
}
