package com.service103.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object UrlStore {
    private const val PREF = "service103"
    private const val KEY = "urls"

    fun get(context: Context): MutableList<UrlItem> {
        val raw = context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .getString(KEY, "[]") ?: "[]"
        val result = mutableListOf<UrlItem>()
        val arr = JSONArray(raw)
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            result.add(UrlItem(o.optString("title"), o.optString("url"), o.optString("agent")))
        }
        return result
    }

    fun save(context: Context, items: List<UrlItem>) {
        val arr = JSONArray()
        items.forEach {
            arr.put(JSONObject().apply {
                put("title", it.title)
                put("url", it.url)
                put("agent", it.userAgent)
            })
        }
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE)
            .edit().putString(KEY, arr.toString()).apply()
    }

    fun add(context: Context, item: UrlItem) {
        val items = get(context)
        items.add(item)
        save(context, items)
    }

    fun delete(context: Context, index: Int) {
        val items = get(context)
        if (index in items.indices) {
            items.removeAt(index)
            save(context, items)
        }
    }
}
