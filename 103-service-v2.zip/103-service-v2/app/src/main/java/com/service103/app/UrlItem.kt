package com.service103.app

data class UrlItem(
    val title: String,
    val url: String,
    val userAgent: String = ""
)
