package com.service103.app

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.service103.app.databinding.ActivityLinksBinding

class LinksActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLinksBinding
    private lateinit var adapter: UrlAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLinksBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.backButton.setOnClickListener { finish() }
        adapter = UrlAdapter(
            onPlay = { item ->
                startActivity(Intent(this, PlayerActivity::class.java).apply {
                    putExtra("url", item.url)
                    putExtra("agent", item.userAgent)
                    putExtra("title", item.title)
                })
            },
            onDelete = { position ->
                UrlStore.delete(this, position)
                refresh()
            }
        )
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = adapter
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        adapter.submit(UrlStore.get(this))
    }
}
