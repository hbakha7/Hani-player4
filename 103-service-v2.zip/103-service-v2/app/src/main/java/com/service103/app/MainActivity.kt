package com.service103.app

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.service103.app.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.menuButton.setOnClickListener { toggleDrawer() }
        binding.onlineButton.setOnClickListener {
            startActivity(Intent(this, LinksActivity::class.java))
        }
        binding.linksButton.setOnClickListener {
            startActivity(Intent(this, LinksActivity::class.java))
        }
        binding.addButton.setOnClickListener {
            startActivity(Intent(this, AddUrlActivity::class.java))
        }

        binding.drawerHome.setOnClickListener { closeDrawer() }
        binding.drawerLinks.setOnClickListener {
            closeDrawer()
            startActivity(Intent(this, LinksActivity::class.java))
        }
        binding.drawerAdd.setOnClickListener {
            closeDrawer()
            startActivity(Intent(this, AddUrlActivity::class.java))
        }
        binding.drawerShare.setOnClickListener {
            val share = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, "103 SERVICE")
            }
            startActivity(Intent.createChooser(share, "Share 103 SERVICE"))
        }
        binding.drawerPrivacy.setOnClickListener {
            android.widget.Toast.makeText(this, "Privacy Policy — add your policy URL/text here.", android.widget.Toast.LENGTH_LONG).show()
        }
        binding.drawerContact.setOnClickListener {
            android.widget.Toast.makeText(this, "Contact us — add your email here.", android.widget.Toast.LENGTH_LONG).show()
        }
    }

    private fun toggleDrawer() {
        binding.drawer.visibility =
            if (binding.drawer.visibility == View.VISIBLE) View.GONE else View.VISIBLE
    }

    private fun closeDrawer() {
        binding.drawer.visibility = View.GONE
    }

    override fun onBackPressed() {
        if (binding.drawer.visibility == View.VISIBLE) {
            closeDrawer()
        } else {
            super.onBackPressed()
        }
    }
}
